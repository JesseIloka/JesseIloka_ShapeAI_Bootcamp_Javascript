import React from "react";

function Info(){
  return (
    <div class = "note">
      <h1>Javascript and React JS</h1>
      <p>Basic Web Dev React JS Bootcamp</p>
    </div>
  );
}


export default Info;