import React from "react";
import Footer from "./Footer";
import Header from "./Header";
import Info from "./Info";

function App() {
  return (
    <div>
      <Header />
      <Footer />
      <Info />
      <Info />
      <Info />
      <Info />
      <Info />
      <Info />
    </div>
  );
}

export default App;
